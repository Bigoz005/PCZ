import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        String name = "";
        Set<String> nameSet = new HashSet<>();
        System.out.println("Add new name: (type \"end\" to finish) ");
        while(!name.equals("end")){
            name = scan.nextLine();
            if(!name.equals("end")){
                nameSet.add(name);
            }
        }

        for (String iteratorName : nameSet) {
            System.out.println(iteratorName);
        }
    }
}
