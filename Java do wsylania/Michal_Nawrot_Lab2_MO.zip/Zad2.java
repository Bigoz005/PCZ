import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        boolean flag = true;
        String name1 = "";
        String name2 = "";
        Map<String, String> nameMap = new HashMap<>();
        System.out.println("type \"end\" to finish");
        while(flag){
            System.out.println("Add name of 1st partner: ");
            name1 = scan.nextLine();
            if(name1.equals("end")){
                flag = false;
            }else{
                System.out.println("Add name of 2nd partner: ");
                name2 = scan.nextLine();
                if (name2.equals("end")) {
                    flag = false;
                }else{
                    nameMap.put(name1, name2);
                }
            }
        }

        System.out.println("Type name of the 1st partner");
        name1 = scan.nextLine();
        if(nameMap.containsKey(name1)) {
            System.out.println("Name of 2nd parter is: " + nameMap.get(name1));
        }else{
            System.out.println("There is no such name in the collection");
        }
    }
}
