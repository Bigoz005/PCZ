public class Command {

    private String commandString;

    public Command(String command) {
        this.commandString = command;
    }

    public void execute(){
        System.out.println(commandString);
    }
}
