import java.util.LinkedList;

public class CommandEx {
    public void executeCommandsFromQueue(LinkedList<Command> queue) {
        if (queue != null) {
            queue.forEach(Command::execute);
        }
    }
}
