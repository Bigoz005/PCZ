public class Main {
    public static void main(String[] args) {
        Queue queue = new Queue();
        CommandEx commandEx = new CommandEx();
        Command[] commands = {
                new Command("1"),
                new Command("2"),
                new Command("3"),
        };
        commandEx.executeCommandsFromQueue(queue.setQueue(commands));
    }
}
