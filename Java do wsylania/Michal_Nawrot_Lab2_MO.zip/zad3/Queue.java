import java.util.LinkedList;

public class Queue {
    private LinkedList<Command> queue = new LinkedList<>();

    public LinkedList<Command> setQueue(Command[] commands) {
        if (commands != null) {
            for (Command command: commands
                 ) {
                queue.add(command);
            }
        }

        return queue;
    }
}
