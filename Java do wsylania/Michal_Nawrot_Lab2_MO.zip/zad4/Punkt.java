public class Punkt {
    private Double x;
    private Double y;

    public Punkt() {
        this.x = 0.0;
        this.y = 0.0;
    }

    public Punkt(int x, int y) {
        this.x = (double)x;
        this.y = (double)y;
    }

    public Punkt(Double x, Double y) {
        this.x = x;
        this.y = y;
    }

    public void wyswietl() {
        System.out.println("x: " + x + ", y: " + y);
    }

    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }
}
