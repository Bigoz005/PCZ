import java.util.ArrayList;

public class Garaz {
    private ArrayList<Samochod> garaz = new ArrayList<>();
    private final int rozmiarGarazu;

    public Garaz() {
        rozmiarGarazu = 3;
    }

    public Garaz(int size) {
        if (size > 0) {
            rozmiarGarazu = size;

        } else {
            rozmiarGarazu = 3;
        }
    }

    public void wprowadz(Samochod samochod) {
        if (garaz.size() < rozmiarGarazu) {
            this.garaz.add(samochod);
        } else {
            System.out.println("Nie ma miejsca dla: " + samochod.wyswietl());
        }
    }

    public void wyprowadz(Samochod samochod) {
        if (garaz.contains(samochod)) {
            garaz.remove(samochod);
        } else {
            System.out.println("W garazu nie ma " + samochod.wyswietl());
        }
    }

    public void wyswietl() {
        System.out.println("Auta w garazu:");
        for (Samochod samochod : garaz) {
            System.out.println(samochod.wyswietl());
        }
        System.out.println("\n");
    }

    public Boolean szukaj(String marka) {
        for (Samochod samochod : garaz
        ) {
            if (samochod.getMarka().toLowerCase().equals(marka.toLowerCase()))
                return true;
        }
        return false;
    }

    public void liczbaWolnych() {
        System.out.println("Wolnych miejsc: " + (rozmiarGarazu - garaz.size()) + '\n');
    }
}
