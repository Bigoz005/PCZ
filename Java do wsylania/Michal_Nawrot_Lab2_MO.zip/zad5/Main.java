public class Main {
    public static void main(String[] args) {
        Samochod s1 = new Samochod("mazda", "rx7", 105.0,1.1,1999);
        Samochod s2 = new Samochod("nissan", "r34", 60.0,1.6,2002);

        Garaz garaz = new Garaz(4);

        garaz.wyswietl();
        garaz.liczbaWolnych();

        garaz.wprowadz(s1);
        garaz.wprowadz(s2);

        garaz.wyswietl();
        garaz.liczbaWolnych();

        garaz.wyprowadz(s2);
        garaz.wyswietl();
        garaz.liczbaWolnych();

        System.out.println("Mazda: " + garaz.szukaj("mazda"));
        System.out.println("Nissan: " + garaz.szukaj("nissan"));
    }
}
