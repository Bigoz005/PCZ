public class Samochod {

    private String marka;
    private String model;
    private Double moc;
    private Double pojemnosc;
    private Integer rok_produkcji;

    public Samochod(String marka, String model, Double moc, Double pojemnosc, Integer rok_produkcji) {
        this.marka = marka;
        this.model = model;
        this.moc = moc;
        this.pojemnosc = pojemnosc;
        this.rok_produkcji = rok_produkcji;
    }

    public String wyswietl() {
        return "marka='" + marka + '\'' + ", model='" + model + '\'' + ", moc='" + moc +
                '\'' + ", pojemnosc=" + pojemnosc + '\'' + ", rok_produkcji=" + rok_produkcji;
    }

    public String getMarka() {
        return marka;
    }

    public String getModel() {
        return model;
    }

    public Double getMoc() {
        return moc;
    }

    public Double getPojemnosc() {
        return pojemnosc;
    }

    public Integer getRok_produkcji() {
        return rok_produkcji;
    }
}
