import java.util.Objects;

public class Autor {
    private String imie;
    private String nazwisko;
    private String narodowosc;

    public Autor(String imie, String nazwisko, String narodowosc) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.narodowosc = narodowosc;
    }

    public String getImie() {
        return imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getNarodowosc() {
        return narodowosc;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Autor)) return false;
        Autor autor = (Autor) o;
        return Objects.equals(nazwisko, autor.nazwisko) && Objects.equals(imie, autor.imie) && Objects.equals(narodowosc, autor.narodowosc);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imie, nazwisko, narodowosc);
    }

    @Override
    public String toString() {
        return "imie:" + imie + '\n' + "nazwisko:" + nazwisko + '\n' + "narodowosc:" + narodowosc + '\n';
    }
}
