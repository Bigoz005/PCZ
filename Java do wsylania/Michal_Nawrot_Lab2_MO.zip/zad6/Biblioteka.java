import java.util.ArrayList;
import java.util.List;

public class Biblioteka {
    private List<Pozycja> pozycje;
    private String adres;

    public Biblioteka(String adres) {
        pozycje = new ArrayList<>();
        this.adres = adres;
    }

    public Biblioteka(List<Pozycja> pozycje, String adres) {
        this.pozycje = pozycje;
        this.adres = adres;
    }

    public void dodaj(Pozycja pozycja) {
        this.pozycje.add(pozycja);
    }

    public void usun(Pozycja pozycja) {
        this.pozycje.remove(pozycja);
    }

    public void wyswietlAdres() {
        System.out.println(this.adres);
    }

    public void wyswietlInfoKsiazek() {
        System.out.println("|/\\|/\\|/\\|/\\|/\\|/\\|/\\|/\\|/\\|/\\|/\\|/\\");
        System.out.println("Ksiazki: ");
        this.pozycje.forEach(Pozycja::wypiszInfo);
        System.out.println("\n");
    }

    public Pozycja[] szukajPoRokuWydania(int rokWydania) {
        return this.pozycje
                .stream()
                .filter(pozycja -> pozycja.getRokWydania() == rokWydania)
                .toArray(Pozycja[]::new);
    }

    public Pozycja[] szukajPoTytule(String tytul) {
        return this.pozycje
                .stream()
                .filter(pozycja -> pozycja.getTytul().toLowerCase().equals(tytul.toLowerCase()))
                .toArray(Pozycja[]::new);
    }

    public Pozycja[] szukajPoAutorze(Autor autor) {
        return this.pozycje
                .stream()
                .filter(pozycja -> pozycja.posiadaAutora(autor))
                .toArray(Pozycja[]::new);
    }

    public Pozycja szukajPoId(int id) {
        return this.pozycje
                .stream()
                .filter(pozycja -> pozycja.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public String getAdres() {
        return adres;
    }
}
