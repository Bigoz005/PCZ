import java.util.List;

public class Czasopismo extends Pozycja {
    private String streszczenie;
    private int numer;

    public Czasopismo(List<Autor> listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul, String streszczenie, int numer) {
        super(listaAutorow, id, wydawnictwo, rokWydania, tytul);
        this.streszczenie = streszczenie;
        this.numer = numer;
    }

    public Czasopismo(Autor[] listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul, String streszczenie, int numer) {
        super(listaAutorow, id, wydawnictwo, rokWydania, tytul);
        this.streszczenie = streszczenie;
        this.numer = numer;
    }

    @Override
    public void wypiszInfo() {
        System.out.println(toString());
    }

    public String getStreszczenie() {
        return streszczenie;
    }

    public int getNumer() {
        return numer;
    }


    @Override
    public String toString() {
        return super.toString() + '\n' + "streszczenie:" + streszczenie + '\n' + "numer:" + numer;
    }
}
