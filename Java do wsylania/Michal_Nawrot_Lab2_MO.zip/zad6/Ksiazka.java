import java.util.List;

public class Ksiazka extends Pozycja {

    private int strony;

    public Ksiazka(List<Autor> listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul, int strony) {
        super(listaAutorow, id, wydawnictwo, rokWydania, tytul);
        this.strony = strony;
    }

    public Ksiazka(Autor[] listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul, int strony) {
        super(listaAutorow, id, wydawnictwo, rokWydania, tytul);
        this.strony = strony;
    }

    @Override
    public void wypiszInfo() {
        System.out.println(toString());
    }

    public int getStrony() {
        return strony;
    }


    @Override
    public String toString() {
        return super.toString() + '\n' + "strony:" + strony;
    }
}
