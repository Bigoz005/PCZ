import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Biblioteka biblioteka = new Biblioteka("Łódź ul.Adrzeja Struga 7 90-420  42 633 76 77");

        Ksiazka ksiazka1 = new Ksiazka(new Autor[]{new Autor("Jan","Kowalski","Polak")}, 1, "PWN", 2020, "ksiazka1", 1488);
        Ksiazka ksiazka2 = new Ksiazka(new Autor[]{new Autor("Koln","Frones","Holender")}, 2, "Helion", 2005, "ksiazka2", 256);

        Czasopismo czasopismo1 = new Czasopismo(new Autor[]{new Autor("Zbigniew","Boniek","Polak")}, 3, "Fantastyka", 2014, "czasopismo1","czasopismo1", 10);
        Czasopismo czasopismo2 = new Czasopismo(new Autor[]{new Autor("Zbigniew","Boniek","Polak")}, 3, "Fantastyka", 2014, "czasopismo2","czasopismo2", 10);
        biblioteka.dodaj(ksiazka1);
        biblioteka.dodaj(ksiazka2);

        biblioteka.dodaj(czasopismo1);
        biblioteka.dodaj(czasopismo2);

        ksiazka2.dodajAutora(new Autor("Zbigniew", "Chrobry", "Polak"));

        biblioteka.wyswietlInfoKsiazek();

        biblioteka.usun(ksiazka2);

        System.out.println("ksiazka1 " + Arrays.toString(biblioteka.szukajPoTytule("ksiazka1")));
        System.out.println("czasopismo1 " + Arrays.toString(biblioteka.szukajPoTytule("czasopismo1")));
        System.out.println("id 3 " + biblioteka.szukajPoId(3));
        System.out.println("2005 " + Arrays.toString(biblioteka.szukajPoRokuWydania(2005)));
        System.out.println("autor Jan Kowalski" + Arrays.toString(biblioteka.szukajPoAutorze(new Autor("Jan", "Kowalski", "Polak"))));
        System.out.println("autor Zbigniew Boniek" + Arrays.toString(biblioteka.szukajPoAutorze(new Autor("Zbigniew", "Boniek", "Polak"))));

        biblioteka.wyswietlInfoKsiazek();
    }
}
