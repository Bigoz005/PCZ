import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public abstract class Pozycja {
    private List<Autor> listaAutorow;
    private int id;
    private String wydawnictwo;
    private int rokWydania;
    private String tytul;

    public Pozycja(List<Autor> listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul) {
        this.listaAutorow = listaAutorow;
        this.id = id;
        this.wydawnictwo = wydawnictwo;
        this.rokWydania = rokWydania;
        this.tytul = tytul;
    }

    public Pozycja(Autor[] listaAutorow, int id, String wydawnictwo, int rokWydania, String tytul) {
        this.listaAutorow = new ArrayList<>(Arrays.asList(listaAutorow));
        this.id = id;
        this.wydawnictwo = wydawnictwo;
        this.rokWydania = rokWydania;
        this.tytul = tytul;
    }

    public Autor[] getListaAutorow() {
        return (Autor[]) listaAutorow.toArray();
    }

    public int getId() {
        return id;
    }

    public String getWydawnictwo() {
        return wydawnictwo;
    }

    public int getRokWydania() {
        return rokWydania;
    }

    public String getTytul() {
        return tytul;
    }

    public abstract void wypiszInfo();

    public void dodajAutora(Autor autor) {
        listaAutorow.add(autor);
    }

    public boolean posiadaAutora(Autor autor) {
        return listaAutorow.contains(autor);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pozycja)) return false;
        Pozycja pozycja = (Pozycja) o;
        return id == pozycja.id && Objects.equals(wydawnictwo, pozycja.wydawnictwo) && Objects.equals(listaAutorow, pozycja.listaAutorow) && rokWydania == pozycja.rokWydania;
    }

    @Override
    public int hashCode() {
        return Objects.hash(listaAutorow, id, wydawnictwo, rokWydania);
    }


    @Override
    public String toString() {
        return "tytul:" + tytul + '\n' + "id:" + id + '\n' + "listaAutorow:\n" + listaAutorow + '\n' + "wydawnictwo:" + wydawnictwo + '\n' + "rokWydania:" + rokWydania;
    }
}
