package com.company;

public class Circle implements IFigura {

    private double r;

    Circle(double r) {
        setR(r);
    }

    @Override
    public void wyswietl() {
        System.out.println("Koło: r=" + r);
    }

    @Override
    public void obliczObwod() {
        System.out.println("Obwód koła: " + (2 * r * Math.PI));
    }

    @Override
    public void obliczPole() {
        System.out.println("Pole koła: " + ((r * r) * Math.PI));
    }

    public double getR() {
        return r;
    }

    public void setR(double r) {
        this.r = r;
    }
}
