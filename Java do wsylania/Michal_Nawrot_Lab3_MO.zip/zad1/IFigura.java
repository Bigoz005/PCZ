package com.company;

public interface IFigura {
    void wyswietl();
    void obliczObwod();
    void obliczPole();
}
