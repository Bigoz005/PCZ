package com.company;

import java.util.HashSet;

public class Main {

    public static void main(String[] args) {
        Square square = new Square(14.0);
        Rectangle rect = new Rectangle(14.0, 5.0);
        Circle circle = new Circle(3.0);
        Triangle triangle = new Triangle(5.0, 3.0, 4.0);
        Trapezoid trapezoid = new Trapezoid(2.0,3.0, 10.0, 9.0, 7.0);
        IFigura[] setFigur = new IFigura[5];

        setFigur[0]=square;
        setFigur[1]=rect;
        setFigur[2]=circle;
        setFigur[3]=triangle;
        setFigur[4]=trapezoid;

        for (IFigura figura:setFigur) {
            figura.wyswietl();
            figura.obliczObwod();
            figura.obliczPole();
        }
    }
}
