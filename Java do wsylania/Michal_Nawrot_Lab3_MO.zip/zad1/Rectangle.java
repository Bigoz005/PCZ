package com.company;

public class Rectangle implements IFigura {

    private double a;
    private double b;

    Rectangle(double a, double b) {
        setA(a);
        setB(b);
    }

    @Override
    public void wyswietl() {
        System.out.println("Prostokąt: a=" + a + "; b=" + b);
    }

    @Override
    public void obliczObwod() {
        System.out.println("Obwód prostokąta: " + (2 * b + 2 * a));
    }

    @Override
    public void obliczPole() {
        System.out.println("Pole prostokąta: " + (a * b));
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
}
