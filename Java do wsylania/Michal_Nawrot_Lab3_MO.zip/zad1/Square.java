package com.company;

public class Square implements IFigura {

    private double a;

    Square(double a) {
        setA(a);
    }

    @Override
    public void wyswietl() {
        System.out.println("Kwadrat: a=" + a);
    }

    @Override
    public void obliczObwod() {
        System.out.println("Obwód kwadratu: " + (4 * a));
    }

    @Override
    public void obliczPole() {
        System.out.println("Pole kwadratu: " + (a * a));
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }
}
