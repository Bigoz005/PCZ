package com.company;

public class Trapezoid implements IFigura {

    private double a;
    private double b;
    private double c;
    private double d;
    private double h;

    Trapezoid(double a, double b, double c, double d, double h) {
        setA(a);
        setB(b);
        setC(c);
        setD(d);
        setH(h);
    }

    @Override
    public void wyswietl() {
        System.out.println("Trapez: a=" + a + "; b=" + b + "; c=" + c + "; d=" + d + "; h=" + h);
    }

    @Override
    public void obliczObwod() {
        System.out.println("Obwód trapezu: " + (a + b + c + d));
    }

    @Override
    public void obliczPole() {
        System.out.println("Pole trapez: " + (((a + b) * h) / 2));
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }

    public double getD() {
        return d;
    }

    public void setD(double d) {
        this.d = d;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }
}
