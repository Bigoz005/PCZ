package com.company;

public class Triangle implements IFigura {

    private double a;
    private double b;
    private double c;

    Triangle(double a, double b, double c) {
        setA(a);
        setB(b);
        setC(c);
    }

    @Override
    public void wyswietl() {
        System.out.println("Trójkąt: a=" + a + "; b=" + b + "; c=" + c);
    }

    @Override
    public void obliczObwod() {
        System.out.println("Obwód trójkąta: " + (a + b + c));
    }

    @Override
    public void obliczPole() {
        double temp = (a + b + c) / 2;
        System.out.println("Pole trójkąta: " + Math.sqrt(temp * (temp - a) * (temp - b) * (temp - c)));
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }

    public double getC() {
        return c;
    }

    public void setC(double c) {
        this.c = c;
    }
}
