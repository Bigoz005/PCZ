package com.company;

public interface Behaviour {

    void jedz(double distanceInKm);

    void tankuj(double injectFuel);
}

