package com.company;

public class Combustion{

    Combustion(double capacity, double power, double combustion, double fuelAmount, String fuelType){
        setCapacity(capacity);
        setPower(power);
        setCombustion(combustion);
        setFuelAmount(fuelAmount);
        setFuelType(fuelType);
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getPower() {
        return power;
    }

    public void setPower(double power) {
        this.power = power;
    }

    public double getCombustion() {
        return combustion;
    }

    public void setCombustion(double combustion) {
        this.combustion = combustion;
    }

    public double getFuelAmount() {
        return fuelAmount;
    }

    public void setFuelAmount(double fuelAmount) {
        this.fuelAmount = fuelAmount;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    private double capacity;
    private double power;
    private double combustion;
    private double fuelAmount;
    private String fuelType;
}
