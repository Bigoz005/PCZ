package com.company;

public class Dostawczy extends Vehicle implements Behaviour {

    private int capacityOfTruck;
    private Combustion combustionEngine;

    public Dostawczy(int capacityOfTruck, String number, String vinNumber, String color, double odometer, double price, double capacity, double power, double combustion, double fuelAmount, String fuelType){
        setCapacityOfTruck(capacityOfTruck);
        combustionEngine = new Combustion(capacity, power, combustion, fuelAmount, fuelType);
        super.setVars(number, vinNumber, color, odometer, price);
    }

    public int getCapacityOfTruck() {
        return capacityOfTruck;
    }

    public void setCapacityOfTruck(int capacityOfTruck) {
        this.capacityOfTruck = capacityOfTruck;
    }

    @Override
    public void jedz(double distanceInKm) {
        double tempFuel = combustionEngine.getFuelAmount();
        tempFuel -= distanceInKm * (combustionEngine.getCombustion() / 100);
        if (tempFuel < 0) {
            combustionEngine.setFuelAmount(0);
        } else {
            combustionEngine.setFuelAmount(tempFuel);
        }
        odometer += distanceInKm;
    }

    @Override
    public void tankuj(double injectFuel) {
        double tempFuel = combustionEngine.getFuelAmount();
        tempFuel += injectFuel;
        if (tempFuel > 100) {
            combustionEngine.setFuelAmount(100);
        } else {
            combustionEngine.setFuelAmount(tempFuel);
        }
    }


    public void printInfo() {
        System.out.println(" capacity of truck: " + capacityOfTruck + "\n fuel type: " + combustionEngine.getFuelType() + "\n capacity: " + combustionEngine.getCapacity() + "\n fuel combustion per 100km: " + combustionEngine.getCombustion() + "\n fuel amount: " + combustionEngine.getFuelAmount() + "\n horse power: " + combustionEngine.getPower());
        super.printInfo();
        System.out.println("------------+++++++++-----------");
    }
}
