package com.company;

public class Electrical{

    Electrical(double energyLeft, double consumptionLevel){
        setEnergyLeft(energyLeft);
        setConsumptionLevel(consumptionLevel);
    }

    public double getEnergyLeft() {
        return energyLeft;
    }

    public void setEnergyLeft(double energyLeft) {
        this.energyLeft = energyLeft;
    }

    public double getConsumptionLevel() {
        return consumptionLevel;
    }

    public void setConsumptionLevel(double consumptionLevel) {
        this.consumptionLevel = consumptionLevel;
    }

    private double energyLeft = 50;
    private double consumptionLevel = 50;
}
