package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	    Osobowy osobowe1 = new Osobowy(5,"WB 1231", "213231scX231", "Red", 14000.5, 15, 50, 10);
        Motocykl motocykl1 = new Motocykl(3,"SCZ 1351", "215561scX231", "Black", 87000.5, 11, 13, 8);
        Dostawczy dostawcze1 = new Dostawczy(120,"BG 12S3", "Pojjk12oj31", "Red", 14000.5, 15, 14.4, 150, 12.6, 60, "Pb98");
        Ciezarowy ciezarowe1 = new Ciezarowy(240,"OWJ 1266", "X23v2cX231", "Red", 14000.5, 15,  6.9, 113, 8.5, 10, "Pb95");
        Osobowy osobowe2 = new Osobowy(4,"KJ 1311", "XC231Xcs123", "Blue", 50000.5, 166, 69, 4.20);
        Motocykl motocykl2 = new Motocykl(2,"EL 1D251", "2155zz1scX2b1", "Purple", 97000.5, 522, 12, 4);
        Dostawczy dostawcze2 = new Dostawczy(400,"TR 6K7I8", "21zz213cX2b1", "Silver", 140000.5, 23,  12.4, 130, 10.6, 90, "DIESEL");
        Ciezarowy ciezarowe2 = new Ciezarowy(500,"WR 51C21", "25zZF23scX2b1", "White", 424000.5, 17,  6.4, 100, 7.6, 40, "Pb95");

        ArrayList<Vehicle> listOfVehicles = new ArrayList<Vehicle>();
        listOfVehicles.add(osobowe1);
        listOfVehicles.add(osobowe2);
        listOfVehicles.add(motocykl1);
        listOfVehicles.add(motocykl2);
        listOfVehicles.add(dostawcze1);
        listOfVehicles.add(dostawcze2);
        listOfVehicles.add(ciezarowe1);
        listOfVehicles.add(ciezarowe2);

        for (Vehicle vehicle:listOfVehicles) {
            vehicle.printInfo();
        }

        ciezarowe1.jedz(15);
        osobowe1.tankuj(40);

        for (Vehicle vehicle:listOfVehicles) {
            vehicle.printInfo();
        }
    }
}
