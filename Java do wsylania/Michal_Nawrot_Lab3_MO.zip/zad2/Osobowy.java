package com.company;

public class Osobowy extends Vehicle implements Behaviour {

    private int doorsAmount;
    private Electrical electricalEngine;

    public Osobowy(int doors, String number, String vinNumber, String color, double odometer, double price, double energyLeft, double consuptionLevel) {
        setDoorsAmount(doors);
        electricalEngine = new Electrical(energyLeft,consuptionLevel);
        super.setVars(number, vinNumber, color, odometer, price);
    }

    public int getDoorsAmount() {
        return doorsAmount;
    }

    public void setDoorsAmount(int doorsAmount) {
        this.doorsAmount = doorsAmount;
    }

    @Override
    public void jedz(double distanceInKm) {
        double tempEnergy = electricalEngine.getEnergyLeft();
        tempEnergy -= distanceInKm * (electricalEngine.getConsumptionLevel() / 100);
        if (tempEnergy < 0) {
            electricalEngine.setEnergyLeft(0);
        } else {
            electricalEngine.setEnergyLeft(tempEnergy);
        }
        odometer += distanceInKm;
    }

    @Override
    public void tankuj(double injectFuel) {
        double tempEnergy = electricalEngine.getEnergyLeft();
        tempEnergy += injectFuel;
        if (tempEnergy > 100) {
            electricalEngine.setEnergyLeft(100);
        } else {
            electricalEngine.setEnergyLeft(tempEnergy);
        }
    }


    public void printInfo() {
        System.out.println(" doors Amount: " + doorsAmount + "\n energy left: " + electricalEngine.getEnergyLeft() + "\n energy consumption: " + electricalEngine.getConsumptionLevel());
        super.printInfo();
        System.out.println("------------+++++++++-----------");
    }
}
