package com.company;

public abstract class Vehicle {

    String number = "";
    String vinNumber = "";
    String color = "";
    double odometer = 0;
    double price = 0;

    void setVars(String number, String vinNumber, String color, double odometer, double price) {
        this.number = number;
        this.vinNumber = vinNumber;
        this.color = color;
        this.odometer = odometer;
        this.price = price;
    }

    void printInfo() {
        System.out.println(" plate number: " + number + "\n vin Number: " + vinNumber + "\n color: " + color + "\n odometer: " + odometer + "\n price: " + price);
    }
}
