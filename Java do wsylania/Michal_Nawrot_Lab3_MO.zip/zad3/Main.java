package com.company;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        List<String> listOfWords = new ArrayList<String>();
        List<String> wordsToSave = new ArrayList<String>();

        System.out.println("Search for a sign: ");

        Scanner scan = new Scanner(System.in);
        String sign = scan.nextLine();

        try {
            Path path = FileSystems.getDefault().getPath("test");
            Scanner reader = new Scanner(new File(path.toString()));
            String line;
            while (reader.hasNextLine()) {
                line = reader.nextLine();
                System.out.println(line);
                for (String word : line.split("\\s+")) {
                    if (!word.isEmpty())
                        listOfWords.add(word.toLowerCase());
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }

        System.out.println("---------------");
        System.out.println("Words to save");

        for (String word : listOfWords) {
            if (word.contains(sign)) {
                if (word.indexOf(sign) != word.lastIndexOf(sign)) {
                    wordsToSave.add(word);
                    System.out.println(word);
                }
            }
        }

        try {
            Path outputPath = FileSystems.getDefault().getPath("output");
            Files.write(outputPath, wordsToSave, StandardCharsets.UTF_8);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
