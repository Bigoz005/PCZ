package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Komis {

    private String address;
    private String name;
    private ArrayList<Samochod> listaSamochodow = new ArrayList<Samochod>();

    Komis(String address, String name) {
        setAddress(address);
        setName(name);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Samochod> getListaSamochodow() {
        return listaSamochodow;
    }

    public void setListaSamochodow(ArrayList<Samochod> listaSamochodow) {
        this.listaSamochodow = listaSamochodow;
    }

    public void showAllCars() {
        listaSamochodow
                .stream()
                .forEach(e -> System.out.println(e.toString()));
    }

    public void showCarsOfPrice(double price) {
        listaSamochodow
                .stream()
                .filter(e -> e.getPrice() <= price)
                .forEach(e -> System.out.println(e.toString()));
    }

    public void showCarsOfBrand(String marka) {
        listaSamochodow
                .stream()
                .filter(e -> e.getMarka().equals(marka))
                .forEach(e -> System.out.println(e.toString()));
    }

    public void sprzedaj(String marka, String model, int yearOfProduction) {
        listaSamochodow.removeIf(e -> e.getMarka().equals(marka) && e.getModel().equals(model) && e.getYearOfProduction() == yearOfProduction);
    }

    public void zapisz() {
        try {
            PrintWriter writer = new PrintWriter("./output");
            for (Samochod samochod : listaSamochodow) {
                writer.println(samochod.toString());
            }
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void wczytaj() {
        try {
            Path path = FileSystems.getDefault().getPath("output");
            Scanner reader = new Scanner(new File(path.toString()));
            String line;
            while (reader.hasNextLine()) {
                line = reader.nextLine();
                String[] tempArray = line.split(" ");
                listaSamochodow.add(new Samochod(tempArray[0], tempArray[1], Double.parseDouble(tempArray[2]), Double.parseDouble(tempArray[3]), Integer.parseInt(tempArray[4]), Double.parseDouble(tempArray[5]), Double.parseDouble(tempArray[6])));
            }
            reader.close();
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
