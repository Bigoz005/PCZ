package com.company;

public class Main {

    public static void main(String[] args) {

        Komis komis = new Komis("Czestochowa 42-242 ul.Sobieskiego 5a/7", "KomisLolo");

        Samochod samochod1 = new Samochod("Audi", "A6", 2.5, 115, 2004, 430000, 45000);
        Samochod samochod2 = new Samochod("BMW", "E47", 4.5, 124, 2000, 660000, 25000);
        Samochod samochod3 = new Samochod("BMW", "E36", 1.5, 165, 2003, 235000, 65000);
        Samochod samochod4 = new Samochod("Ford", "Mustang", 8.5, 345, 2003, 235000, 65000);

        komis.getListaSamochodow().add(samochod1);
        komis.getListaSamochodow().add(samochod2);
        komis.getListaSamochodow().add(samochod3);
        komis.getListaSamochodow().add(samochod4);

        komis.wczytaj();

        System.out.println("-----------");


        komis.showAllCars();

        System.out.println("-----------");

        komis.showCarsOfBrand("Audi");

        System.out.println("-----------");

        komis.showCarsOfPrice(45000);

        System.out.println("-----------");

        komis.sprzedaj("Audi", "A6", 2004);

        komis.showAllCars();

        komis.zapisz();

        System.out.println("-----------");
        System.out.println("-----------");

        komis.showAllCars();

        System.out.println("-----------");
        System.out.println("-----------");
    }
}
