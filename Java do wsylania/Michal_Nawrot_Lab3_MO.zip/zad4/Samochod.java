package com.company;

public class Samochod {

    private String marka;
    private String model;
    private double capacity;
    private double horsePower;
    private int yearOfProduction;
    private double odometer;
    private double price;

    Samochod(String marka, String model, double capacity, double horsePower, int yearOfProduction, double odometer, double price){
        setCapacity(capacity);
        setHorsePower(horsePower);
        setMarka(marka);
        setModel(model);
        setYearOfProduction(yearOfProduction);
        setOdometer(odometer);
        setPrice(price);
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(double horsePower) {
        this.horsePower = horsePower;
    }

    public int getYearOfProduction() {
        return yearOfProduction;
    }

    public void setYearOfProduction(int yearOfProduction) {
        this.yearOfProduction = yearOfProduction;
    }

    public double getOdometer() {
        return odometer;
    }

    public void setOdometer(double odometer) {
        this.odometer = odometer;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return marka + " " + model + " " + capacity + " " + horsePower + " " + yearOfProduction + " " + odometer + " " + price;
    }
}
