import javax.xml.bind.*;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.File;
import java.util.ArrayList;

@XmlRootElement(name="Komis")
public class Komis {

    private String address;
    private String name;
    private ArrayList<Samochod> listaSamochodow = new ArrayList<Samochod>();

    public Komis(){
    }

    public Komis(String address, String name) {
        setAddress(address);
        setName(name);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlElements(@XmlElement(name="Samochod"))
    public ArrayList<Samochod> getListaSamochodow() {
        return listaSamochodow;
    }

    public void setListaSamochodow(ArrayList<Samochod> listaSamochodow) {
        this.listaSamochodow = listaSamochodow;
    }

    public void showAllCars() {
        listaSamochodow
                .stream()
                .forEach(e -> System.out.println(e.toString()));
    }

    public void showCarsOfPrice(double price) {
        listaSamochodow
                .stream()
                .filter(e -> e.getPrice() <= price)
                .forEach(e -> System.out.println(e.toString()));
    }

    public void showCarsOfBrand(String marka) {
        listaSamochodow
                .stream()
                .filter(e -> e.getMarka().equals(marka))
                .forEach(e -> System.out.println(e.toString()));
    }

    public void sprzedaj(String marka, String model, int yearOfProduction) {
        listaSamochodow.removeIf(e -> e.getMarka().equals(marka) && e.getModel().equals(model) && e.getYearOfProduction() == yearOfProduction);
    }

    public void zapisz(Komis komis) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(Komis.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            jaxbMarshaller.marshal(komis, new File(".\\output.xml"));
        } catch (PropertyException e) {
            e.printStackTrace();
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    public Komis wczytaj() {
        try {
            File xmlFile = new File(".\\output.xml");
            JAXBContext jaxbContext = JAXBContext.newInstance(Komis.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            Komis komisTemp = (Komis) jaxbUnmarshaller.unmarshal(xmlFile);
            for(Samochod samochod : komisTemp.getListaSamochodow()) {
                System.out.println(samochod.toString());
            }
            return komisTemp;
        }
        catch(Exception ex) {
            System.out.println(ex.toString());
        }
        return null;
    }
}
